package com.example.hw3_20220601076

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
